#!/bin/bash
export PORT=3001
export NODE_ENV=production
# 아래 두 줄에 실제 값 입력
export OPENAI_API_KEY="여기에_키_입력"
export SESSION_SECRET="랜덤문자열아무거나"

pm2 start index.cjs --name kshaman-api
pm2 save
